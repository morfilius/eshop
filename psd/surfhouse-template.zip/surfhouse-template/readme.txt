Surfhouse is a simple, clean and modern PSD template for a small ecommerce. 
The template consists of well-organized components that are easy modify.

PSD Template Features:
6 Full layered Adobe Photoshop .PSD files.
1 Home Page - home.psd
1 Product Page - productpage.psd
1 Shop Grid Layout - shop-cat-gridx3.psd
1 Cart Layout - cart.psd
1 Chechout Page - checkout.psd
1 Contact Page - contact.psd
Clean Flat UI Design
Retina Display Ready
Bootstrap layout ready
Flexible and Multipurpose
Well organized layers makes it very easy ti update

Fonts: 
FontAwesome - http://fontawesome.io/
Roboto - http://www.fontsquirrel.com/fonts/roboto
Raleway - http://www.fontsquirrel.com/fonts/Raleway

.Surfhouse - Created by Michele Cialone - 2014/theuncreativelab.com

.Surfhouse .psd template is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/). 

You are allowed to use these elements anywhere you want, however well highly appreciate if you will link to our website when you share them - http://theuncreativelab.com

Thanks for supporting our website and enjoy!

Links:
http://theuncreativelab.com
http://2ndself.com


Image Credit: 
http://www.sxc.hu/
http://unsplash.com/
https://www.imcreator.com/free